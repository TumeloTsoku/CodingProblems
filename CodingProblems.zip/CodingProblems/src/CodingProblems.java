import java.util.*;

public class CodingProblems {
    
    // Problem 1: Magic Potion Identifier
    public static String isMagicalPotion(long power) {
        long cubeRoot = Math.round(Math.cbrt(power));
        return (cubeRoot * cubeRoot * cubeRoot == power) ? "YES" : "NO";
    }
    
    // Problem 2: Sneaky Outcomes
    public static int[] findDuplicates(int[] outcomes) {
        Set<Integer> seen = new HashSet<>();
        List<Integer> duplicates = new ArrayList<>();
        
        for (int num : outcomes) {
            if (!seen.add(num)) {
                duplicates.add(num);
            }
        }
        
        return duplicates.stream().mapToInt(Integer::intValue).toArray();
    }
    
    // Problem 3: Reformat String to Alternating Case
    public static String reformatString(String s) {
        StringBuilder result = new StringBuilder();
        boolean toUpper = true;
        
        for (char c : s.toCharArray()) {
            if (Character.isLetter(c)) {
                result.append(toUpper ? Character.toUpperCase(c) : Character.toLowerCase(c));
                toUpper = !toUpper;
            } else {
                result.append(c);
            }
        }
        
        return result.toString();
    }
    
    // Problem 4: Organizing Books into Identical Sets
    public static String canOrganizeBooks(int[] shelf) {
        Map<Integer, Integer> frequencyMap = new HashMap<>();
        
        for (int book : shelf) {
            frequencyMap.put(book, frequencyMap.getOrDefault(book, 0) + 1);
        }
        
        int gcd = -1;
        for (int count : frequencyMap.values()) {
            if (gcd == -1) {
                gcd = count;
            } else {
                gcd = gcd(gcd, count);
            }
        }
        
        return (gcd > 1) ? "YES" : "NO";
    }
    
    private static int gcd(int a, int b) {
        return (b == 0) ? a : gcd(b, a % b);
    }
    
    public static void main(String[] args) {
        // Example usage
        System.out.println(isMagicalPotion(27)); // YES
        System.out.println(isMagicalPotion(30)); // NO
        
        System.out.println(Arrays.toString(findDuplicates(new int[]{0, 3, 2, 1, 3, 2}))); // [2, 3]
        
        System.out.println(reformatString("hello world!")); // "HeLlO wOrLd!"
        
        System.out.println(canOrganizeBooks(new int[]{5, 5, 3, 3, 2, 2})); // YES
    }
}
